@echo off
chcp 65001 >nul
cd /d "%~dp0"
title STRIKEZONE - Arena FPS
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao foi encontrado.
  echo Instale a versao LTS em https://nodejs.org/ e execute este arquivo novamente.
  pause
  exit /b 1
)
if not exist node_modules\ws (
  echo Instalando os componentes do jogo...
  call npm install
  if errorlevel 1 (
    echo Nao foi possivel instalar as dependencias. Verifique a internet.
    pause
    exit /b 1
  )
)
start "" http://localhost:3000
call npm start
pause
