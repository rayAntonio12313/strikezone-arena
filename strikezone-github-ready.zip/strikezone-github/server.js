const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

const server = http.createServer((req, res) => {
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400); return res.end('Bad request'); }
  if (pathname === '/') pathname = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, pathname));
  if (!filePath.startsWith(PUBLIC_DIR + path.sep) && filePath !== path.join(PUBLIC_DIR, 'index.html')) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });
const clients = new Map();
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const cleanName = (value) => String(value || 'Player').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 16) || 'Player';

function send(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}
function broadcast(payload, exceptId = null) {
  const data = JSON.stringify(payload);
  for (const [id, player] of clients) {
    if (id !== exceptId && player.ws.readyState === WebSocket.OPEN) player.ws.send(data);
  }
}
function publicPlayer(player) {
  return {
    id: player.id,
    name: player.name,
    x: player.x,
    y: player.y,
    z: player.z,
    yaw: player.yaw,
    pitch: player.pitch,
    health: player.health,
    kills: player.kills,
    deaths: player.deaths
  };
}
function respawn(player) {
  player.x = (Math.random() - 0.5) * 42;
  player.y = 1.65;
  player.z = (Math.random() - 0.5) * 42;
  player.health = 100;
  player.dead = false;
  broadcast({ type: 'player_respawn', player: publicPlayer(player) });
  send(player.ws, { type: 'you_respawned', player: publicPlayer(player) });
}

wss.on('connection', (ws) => {
  const id = Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
  let joined = false;

  ws.on('message', (buffer) => {
    let msg;
    try { msg = JSON.parse(buffer.toString()); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;

    if (msg.type === 'join' && !joined) {
      joined = true;
      const player = {
        id, ws, name: cleanName(msg.name),
        x: (Math.random() - 0.5) * 42, y: 1.65, z: (Math.random() - 0.5) * 42,
        yaw: 0, pitch: 0, health: 100, kills: 0, deaths: 0, dead: false,
        lastStateAt: 0
      };
      clients.set(id, player);
      send(ws, { type: 'welcome', id, players: [...clients.values()].filter(p => p.id !== id).map(publicPlayer) });
      broadcast({ type: 'player_joined', player: publicPlayer(player) }, id);
      return;
    }

    const player = clients.get(id);
    if (!player || !joined) return;

    if (msg.type === 'state' && !player.dead) {
      const now = Date.now();
      if (now - player.lastStateAt < 35) return;
      player.lastStateAt = now;
      player.x = clamp(Number(msg.x) || 0, -49, 49);
      player.y = clamp(Number(msg.y) || 1.65, 0.5, 4);
      player.z = clamp(Number(msg.z) || 0, -49, 49);
      player.yaw = Number(msg.yaw) || 0;
      player.pitch = clamp(Number(msg.pitch) || 0, -1.5, 1.5);
      broadcast({ type: 'player_state', player: publicPlayer(player) }, id);
    } else if (msg.type === 'fire' && !player.dead) {
      broadcast({ type: 'player_fire', id, x: player.x, y: player.y - 0.18, z: player.z, yaw: player.yaw, pitch: player.pitch, weapon: String(msg.weapon || 'Rifle').slice(0, 24) }, id);
    } else if (msg.type === 'hit' && !player.dead) {
      const target = clients.get(String(msg.target || ''));
      if (!target || target.dead || target.id === player.id) return;
      const dx = target.x - player.x, dz = target.z - player.z;
      const distance = Math.hypot(dx, dz);
      const damage = clamp(Number(msg.damage) || 0, 1, 60);
      if (distance > 55) return;
      target.health = Math.max(0, target.health - damage);
      send(target.ws, { type: 'health', health: target.health, from: player.name });
      broadcast({ type: 'player_hit', shooterId: player.id, targetId: target.id, damage, health: target.health });
      if (target.health <= 0) {
        target.dead = true;
        target.deaths += 1;
        player.kills += 1;
        broadcast({ type: 'player_killed', killerId: player.id, targetId: target.id, killerName: player.name, targetName: target.name });
        send(player.ws, { type: 'stats', kills: player.kills, deaths: player.deaths });
        setTimeout(() => { if (clients.get(target.id) === target && target.dead) respawn(target); }, 2600);
      }
    } else if (msg.type === 'chat') {
      const text = String(msg.text || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 120);
      if (text) broadcast({ type: 'chat', id: player.id, name: player.name, text });
    }
  });

  ws.on('close', () => {
    const player = clients.get(id);
    if (player) {
      clients.delete(id);
      broadcast({ type: 'player_left', id, name: player.name });
    }
  });
  ws.on('error', () => {});
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`STRIKEZONE Arena disponível em http://localhost:${PORT}`);
  console.log('Multiplayer WebSocket ativo no mesmo endereço.');
});
