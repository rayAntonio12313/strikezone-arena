# STRIKEZONE // Arena FPS

Protótipo de jogo 3D para navegador, com arena industrial texturizada, bots locais, oito slots de equipamento, HUD, configurações e multiplayer por WebSocket no mesmo servidor Node.js.

## Rodar no computador

- Instale Node.js 18 ou mais recente.
- Abra esta pasta no terminal.
- Execute `npm install` e depois `npm start`.
- Abra `http://localhost:3000`.

No Windows, também é possível usar `INICIAR-JOGO.bat`.

## Controles

- **W A S D** — movimentar
- **Mouse** — olhar
- **Botão esquerdo** — ação primária
- **Botão direito** — mira
- **R** — recarregar
- **1, 2, 3, 4, 5, 6, 7, 9** — trocar slot
- **Shift** — correr; **Espaço** — pular
- **TAB** — placar; **T** — chat; **ESC** — soltar o mouse/pausar

## Publicar no GitHub e Render

O `render.yaml` já está incluído para publicar como serviço Node no Render. Não use GitHub Pages para hospedar o multiplayer: Pages serve arquivos estáticos e não executa o servidor WebSocket.

1. Crie um repositório em https://github.com/new (por exemplo, `strikezone-arena`).
2. Extraia este ZIP no computador.
3. No repositório, use **Add file → Upload files** e envie o CONTEÚDO desta pasta. `package.json`, `server.js`, `render.yaml` e a pasta `public` devem ficar na raiz do repositório.
4. Faça o commit dos arquivos.
5. No Render, escolha **New → Blueprint** e conecte o repositório GitHub. O Render lerá o `render.yaml`; revise e aplique a configuração.
6. O serviço inicia com `npm start`, escuta em `0.0.0.0` na porta fornecida pelo Render e mantém HTTP e WebSocket no mesmo host.

## Limitações do protótipo

- Os bots são simulados no navegador de cada jogador; o servidor sincroniza os jogadores humanos conectados à mesma instância.
- O multiplayer é uma base de protótipo, sem matchmaking, contas, persistência, anti-cheat ou servidor dedicado de física.
- O Three.js é carregado por CDN, então o navegador precisa de conexão à internet.
