@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo STRIKEZONE - envio para GitHub
echo.
where git >nul 2>nul
if errorlevel 1 (
  echo Git nao foi encontrado. Instale Git for Windows: https://git-scm.com/download/win
  pause
  exit /b 1
)
set /p REPO_URL=Cole a URL HTTPS do repositorio vazio do GitHub: 
if "%REPO_URL%"=="" (
  echo URL nao informada.
  pause
  exit /b 1
)
git init
git branch -M main
git add .
git commit -m "Initial STRIKEZONE Arena project"
git remote remove origin >nul 2>nul
git remote add origin "%REPO_URL%"
git push -u origin main
if errorlevel 1 (
  echo.
  echo O envio nao foi concluido. Verifique a URL e entre no GitHub quando o Git solicitar.
) else (
  echo.
  echo STRIKEZONE enviado ao GitHub!
)
pause
