import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const $ = (id) => document.getElementById(id);
const container = $('game');
const weapons = [
  {slot:'1',name:'Vandal AR',short:'AR',mag:30,reserve:120,damage:26,rate:115,auto:true,reload:1950,aimFov:60,spread:.009,range:90,color:0xd5b16c},
  {slot:'2',name:'Spectre SMG',short:'SMG',mag:36,reserve:144,damage:17,rate:78,auto:true,reload:1750,aimFov:63,spread:.018,range:62,color:0x74a5a0},
  {slot:'3',name:'Bulldog DMR',short:'DMR',mag:20,reserve:80,damage:34,rate:260,auto:false,reload:2050,aimFov:56,spread:.004,range:110,color:0x8495ac},
  {slot:'4',name:'Sentinel SR',short:'SR',mag:5,reserve:35,damage:95,rate:680,auto:false,reload:2450,aimFov:38,spread:.001,range:150,color:0x718caa},
  {slot:'5',name:'Breach SG',short:'SG',mag:8,reserve:40,damage:11,rate:620,auto:false,reload:2200,aimFov:72,spread:.065,range:28,color:0x9b7859,pellets:8},
  {slot:'6',name:'Sidekick',short:'PISTOL',mag:15,reserve:90,damage:22,rate:210,auto:false,reload:1350,aimFov:64,spread:.012,range:60,color:0x9ca9b4},
  {slot:'7',name:'Atlas LMG',short:'LMG',mag:60,reserve:180,damage:20,rate:105,auto:true,reload:2900,aimFov:67,spread:.022,range:75,color:0x858c76},
  {slot:'9',name:'Ranger Carbine',short:'CARBINE',mag:24,reserve:96,damage:29,rate:155,auto:true,reload:1850,aimFov:58,spread:.007,range:100,color:0x9b9f9f}
];
weapons.forEach(w => { w.ammo = w.mag; w.busy = false; });
let currentWeapon = 0;
let settings = {sensitivity:1,fov:90,saturation:110,volume:35,quality:'medium'};
let gameStarted = false, isLocked = false, aiming = false, firing = false, scoreboardOpen = false;
let yaw = 0, pitch = 0, verticalVelocity = 0, onGround = true, jumpPressed = false;
let playerHealth = 100, playerArmor = 50, localKills = 0, localDeaths = 0;
let playerId = null, online = false, socket = null, playerName = 'Player';
let lastShot = 0, reloadTimer = null, respawning = false, chatOpen = false;
const keys = Object.create(null);
const clock = new THREE.Clock();
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x98a7b1);
scene.fog = new THREE.Fog(0x98a7b1, 52, 118);
const camera = new THREE.PerspectiveCamera(settings.fov, innerWidth / innerHeight, 0.08, 220);
camera.rotation.order = 'YXZ';
camera.position.set(0,1.65,38);
scene.add(camera);
const renderer = new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
container.appendChild(renderer.domElement);
renderer.domElement.addEventListener('click', () => { if (gameStarted && !isLocked && !chatOpen) renderer.domElement.requestPointerLock?.(); });

const ambient = new THREE.HemisphereLight(0xd9e6f0,0x48505a,2.0); scene.add(ambient);
const sun = new THREE.DirectionalLight(0xffe4bd,2.4); sun.position.set(-28,42,25); scene.add(sun);
const fill = new THREE.DirectionalLight(0x91b8d2,.75); fill.position.set(35,18,-28); scene.add(fill);

function canvasTexture(draw, repeatX=1, repeatY=1) {
  const c=document.createElement('canvas'); c.width=512; c.height=512;
  const ctx=c.getContext('2d'); draw(ctx,c.width,c.height);
  const tex=new THREE.CanvasTexture(c); tex.colorSpace=THREE.SRGBColorSpace;
  tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.repeat.set(repeatX,repeatY); tex.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy());
  return tex;
}
function noise(ctx,w,h,count=7000,alpha=.12){
  for(let i=0;i<count;i++){const x=Math.random()*w,y=Math.random()*h,s=Math.random()*2+0.4;ctx.fillStyle=Math.random()>.5?`rgba(255,255,255,${Math.random()*alpha})`:`rgba(0,0,0,${Math.random()*alpha})`;ctx.fillRect(x,y,s,s);}
}
const floorTex=canvasTexture((ctx,w,h)=>{
  ctx.fillStyle='#68747b';ctx.fillRect(0,0,w,h);noise(ctx,w,h,14000,.13);
  ctx.strokeStyle='rgba(27,36,43,.24)';ctx.lineWidth=3;
  for(let x=0;x<=w;x+=128){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
  for(let y=0;y<=h;y+=128){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  ctx.strokeStyle='rgba(225,232,232,.13)';ctx.lineWidth=1;
  for(let i=0;i<45;i++){let x=Math.random()*w,y=Math.random()*h;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.random()*70,y+Math.random()*18);ctx.stroke();}
},10,10);
const concreteTex=canvasTexture((ctx,w,h)=>{ctx.fillStyle='#747d80';ctx.fillRect(0,0,w,h);noise(ctx,w,h,11000,.19);ctx.strokeStyle='rgba(25,32,36,.18)';for(let i=0;i<15;i++){let x=Math.random()*w,y=Math.random()*h;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+Math.random()*95,y+Math.random()*75);ctx.stroke();}},2,2);
const metalTex=canvasTexture((ctx,w,h)=>{
  const g=ctx.createLinearGradient(0,0,w,0);g.addColorStop(0,'#36444d');g.addColorStop(.18,'#71808a');g.addColorStop(.22,'#4b5a64');g.addColorStop(.5,'#586872');g.addColorStop(.8,'#35434d');g.addColorStop(1,'#66737c');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
  for(let x=12;x<w;x+=42){ctx.fillStyle='rgba(13,23,30,.24)';ctx.fillRect(x,0,4,h);ctx.fillStyle='rgba(225,235,239,.13)';ctx.fillRect(x+4,0,2,h);}
  noise(ctx,w,h,6000,.12);ctx.fillStyle='#b2bec1';for(let x=22;x<w;x+=84){for(let y of [18,h-18]){ctx.beginPath();ctx.arc(x,y,4,0,Math.PI*2);ctx.fill();}}
},2,1);
const crateTex=canvasTexture((ctx,w,h)=>{
  ctx.fillStyle='#76563b';ctx.fillRect(0,0,w,h);noise(ctx,w,h,7000,.16);
  ctx.strokeStyle='#3e2f23';ctx.lineWidth=9;for(let y=35;y<h;y+=85){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  ctx.strokeStyle='rgba(221,180,125,.3)';ctx.lineWidth=3;for(let y=40;y<h;y+=85){ctx.beginPath();ctx.moveTo(0,y+5);ctx.lineTo(w,y+5);ctx.stroke();}
  ctx.fillStyle='#a27c54';ctx.fillRect(220,0,70,h);ctx.strokeStyle='#40362c';ctx.lineWidth=5;ctx.strokeRect(20,20,w-40,h-40);
},1,1);
const hazardTex=canvasTexture((ctx,w,h)=>{ctx.fillStyle='#20272b';ctx.fillRect(0,0,w,h);ctx.save();ctx.translate(-100,0);ctx.rotate(-Math.PI/4);for(let x=0;x<w+300;x+=90){ctx.fillStyle='#d7a93e';ctx.fillRect(x,0,42,h*2);}ctx.restore();noise(ctx,w,h,2500,.08);},1,1);
const wallMat=new THREE.MeshStandardMaterial({map:concreteTex,roughness:.93});
const metalMat=new THREE.MeshStandardMaterial({map:metalTex,roughness:.72,metalness:.42});
const crateMat=new THREE.MeshStandardMaterial({map:crateTex,roughness:.92});
const hazardMat=new THREE.MeshStandardMaterial({map:hazardTex,roughness:.86});
const floorMat=new THREE.MeshStandardMaterial({map:floorTex,roughness:.98});
const darkMat=new THREE.MeshStandardMaterial({color:0x252e35,roughness:.8});
const worldMeshes=[]; const colliders=[];
function addBox(x,y,z,sx,sy,sz,mat,{collide=true,ray=true,rotation=0}={}){
  const mesh=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),mat);mesh.position.set(x,y,z);mesh.rotation.y=rotation;mesh.castShadow=mesh.receiveShadow=true;scene.add(mesh);
  if(collide)colliders.push({x,z,hx:sx/2,hz:sz/2}); if(ray)worldMeshes.push(mesh);return mesh;
}
function addCylinder(x,y,z,r,h,mat,{collide=true,radial=12}={}){
  const mesh=new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,radial),mat);mesh.position.set(x,y,z);mesh.castShadow=mesh.receiveShadow=true;scene.add(mesh);
  if(collide)colliders.push({x,z,hx:r,hz:r});worldMeshes.push(mesh);return mesh;
}
const floor=new THREE.Mesh(new THREE.PlaneGeometry(110,110),floorMat);floor.rotation.x=-Math.PI/2;floor.position.y=-.08;floor.receiveShadow=true;scene.add(floor);
// Arena perimeter and raised concrete features.
addBox(0,2.2,-50,104,4.4,2,wallMat);addBox(0,2.2,50,104,4.4,2,wallMat);addBox(-50,2.2,0,2,4.4,100,wallMat);addBox(50,2.2,0,2,4.4,100,wallMat);
// Containers, barricades and cover create multiple routes through the arena.
function containerBlock(x,z,length=12,colorMat=metalMat,rotation=0){
  addBox(x,1.5,z,length,3,3,colorMat,{rotation});
  const side=length/2-.5;
  for(let i=-side;i<=side;i+=2){const rib=new THREE.Mesh(new THREE.BoxGeometry(.11,2.78,.12),darkMat);rib.position.set(x+i,1.5,z+1.52);rib.rotation.y=rotation;scene.add(rib);}
  addBox(x,3.08,z,length-.2,.12,3.05,darkMat,{collide:false,ray:true,rotation});
}
containerBlock(-27,-25,13);containerBlock(23,22,13);containerBlock(-5,5,10);containerBlock(35,-26,9);containerBlock(-37,28,9);
// Container ends receive original warning panels.
addBox(-27,1.45,-17.35,3,2.5,.12,hazardMat,{collide:false});addBox(23,1.45,29.35,3,2.5,.12,hazardMat,{collide:false});
// Concrete blocks and low cover.
[
  [-17,-5,6,2.2,3],[-10,-14,4,1.8,3],[15,-6,7,2.2,3],[7,17,5,2,3],
  [-34,4,5,1.5,3],[34,5,5,1.5,3],[-4,-32,7,2.4,3],[6,34,7,2.2,3],
  [-18,23,4,2.5,3],[19,-34,5,2,3]
].forEach(([x,z,sx,sy,sz])=>addBox(x,sy/2,z,sx,sy,sz,wallMat));
// Wooden supply crates in clusters.
[[-14,-25],[-9,-25],[-12,-20],[13,4],[17,4],[15,8],[-31,-7],[-28,-7],[29,33],[33,33]].forEach(([x,z],i)=>{
  const h=i%3===0?2.2:1.55;addBox(x,h/2,z,1.8,h,1.8,crateMat,{rotation:(i%2)*.08});
  addBox(x,h+.025,z,1.85,.07,1.85,darkMat,{collide:false,ray:true});
});
// Barrels, tires and hazard strips.
[[-22,11],[25,-14],[2,-22],[39,12],[-39,-27],[12,29]].forEach(([x,z],i)=>{
  addCylinder(x,.65,z,.56,1.3,i%2?metalMat:darkMat,{radial:14});
  const band=new THREE.Mesh(new THREE.CylinderGeometry(.565,.565,.18,14),hazardMat);band.position.set(x,.68,z);scene.add(band);
});
// Elevated catwalk-style platforms and support pillars.
addBox(0,4.2,-42,18,.65,5,metalMat);addBox(0,2.1,-42,1,4.2,1,darkMat);addBox(-8,2.1,-42,1,4.2,1,darkMat);addBox(8,2.1,-42,1,4.2,1,darkMat);
addBox(0,.2,0,18,.25,.3,hazardMat,{collide:false,ray:false});
// Painted objective-zone rings.
function groundMark(x,z,color){const m=new THREE.Mesh(new THREE.RingGeometry(5.5,5.72,48),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.72,side:THREE.DoubleSide}));m.rotation.x=-Math.PI/2;m.position.set(x,.005,z);scene.add(m);}
groundMark(-31,-34,0xd6ae53);groundMark(31,34,0x69b4d6);

// Player view model: a stylized, fictional weapon assembled from geometric parts.
let viewWeapon=null, muzzleLight=null, muzzleFlashUntil=0;
const gunMat=new THREE.MeshStandardMaterial({color:0x333e49,metalness:.72,roughness:.35});
const accentMat=new THREE.MeshStandardMaterial({color:0xc49a4a,metalness:.65,roughness:.4});
function buildViewWeapon(w){
  if(viewWeapon)camera.remove(viewWeapon);
  viewWeapon=new THREE.Group();
  const tint=new THREE.MeshStandardMaterial({color:w.color,metalness:.55,roughness:.42});
  const add=(geo,mat,x,y,z,sx=1,sy=1,sz=1)=>{const m=new THREE.Mesh(geo,mat);m.position.set(x,y,z);m.scale.set(sx,sy,sz);viewWeapon.add(m);return m;};
  add(new THREE.BoxGeometry(.24,.16,.43),tint,0,0,0);
  add(new THREE.BoxGeometry(.19,.13,.36),gunMat,0,.075,-.06);
  add(new THREE.BoxGeometry(.1,.22,.13),darkMat,0,-.17,.02);
  add(new THREE.BoxGeometry(.11,.12,.22),tint,0,-.12,.22);
  add(new THREE.CylinderGeometry(.035,.035,.48,10),gunMat,0,.015,-.42,1,1,1).rotation.x=Math.PI/2;
  add(new THREE.BoxGeometry(.12,.07,.25),darkMat,0,.06,-.27);
  add(new THREE.BoxGeometry(.18,.045,.16),accentMat,0,.11,-.04);
  if(w.slot==='4'){
    add(new THREE.BoxGeometry(.13,.1,.34),darkMat,0,.19,-.03);
    add(new THREE.CylinderGeometry(.036,.036,.16,10),accentMat,0,.2,-.03,1,1,1).rotation.x=Math.PI/2;
  }
  if(w.slot==='5') add(new THREE.BoxGeometry(.2,.17,.32),gunMat,0,.02,-.38);
  viewWeapon.position.set(.34,-.31,-.57);viewWeapon.rotation.set(-.02,-.035,0);camera.add(viewWeapon);
  muzzleLight=new THREE.PointLight(0xffc56e,0,2);muzzleLight.position.set(0,.02,-.85);viewWeapon.add(muzzleLight);
}
buildViewWeapon(weapons[0]);

// Simple name tag canvas texture for bots and remote players.
function makeNameSprite(text,color='#e5b957'){
  const c=document.createElement('canvas');c.width=256;c.height=64;const ctx=c.getContext('2d');
  ctx.fillStyle='rgba(5,10,16,.78)';ctx.fillRect(0,7,256,50);ctx.strokeStyle=color;ctx.lineWidth=3;ctx.strokeRect(1,8,254,48);
  ctx.font='bold 25px Arial';ctx.fillStyle='#f4f6f8';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(text).slice(0,18),128,33);
  const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;
  const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false}));sprite.scale.set(2.2,.55,1);sprite.position.y=2.45;return sprite;
}

const bots=[];let botTargets=[];const botColors=[0x6f878c,0x7c8275,0x7d6c60,0x526a7b,0x877d69,0x647a72];
function createBot(index,x,z){
  const group=new THREE.Group();const bodyMat=new THREE.MeshStandardMaterial({color:botColors[index%botColors.length],roughness:.78});
  const dark=new THREE.MeshStandardMaterial({color:0x29343d,roughness:.7});const visor=new THREE.MeshStandardMaterial({color:0x8ed0d8,metalness:.6,roughness:.25,emissive:0x17383a});
  const torso=new THREE.Mesh(new THREE.BoxGeometry(.66,.82,.36),bodyMat);torso.position.y=1.05;group.add(torso);
  const vest=new THREE.Mesh(new THREE.BoxGeometry(.69,.48,.39),dark);vest.position.set(0,1.05,-.015);group.add(vest);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.23,12,10),bodyMat);head.position.y=1.68;group.add(head);
  const helmet=new THREE.Mesh(new THREE.SphereGeometry(.255,12,8,0,Math.PI*2,0,Math.PI*.62),dark);helmet.position.y=1.76;group.add(helmet);
  const face=new THREE.Mesh(new THREE.BoxGeometry(.29,.075,.22),visor);face.position.set(0,1.65,-.17);group.add(face);
  for(const side of [-1,1]){
    const arm=new THREE.Mesh(new THREE.BoxGeometry(.18,.65,.2),bodyMat);arm.position.set(side*.43,1.03,-.015);arm.rotation.z=side*-.12;group.add(arm);
    const leg=new THREE.Mesh(new THREE.BoxGeometry(.23,.65,.25),dark);leg.position.set(side*.18,.37,0);group.add(leg);
    const boot=new THREE.Mesh(new THREE.BoxGeometry(.25,.14,.37),dark);boot.position.set(side*.18,.08,-.045);group.add(boot);
  }
  const pack=new THREE.Mesh(new THREE.BoxGeometry(.42,.5,.18),dark);pack.position.set(0,1.12,.25);group.add(pack);
  const tag=makeNameSprite(`BOT-${String(index+1).padStart(2,'0')}`,'#d7b15d');group.add(tag);
  group.position.set(x,0,z);scene.add(group);
  const bodyHit=new THREE.Mesh(new THREE.CylinderGeometry(.37,.37,.95,8),new THREE.MeshBasicMaterial({visible:false}));bodyHit.position.y=1.1;group.add(bodyHit);
  const headHit=new THREE.Mesh(new THREE.SphereGeometry(.27,8,6),new THREE.MeshBasicMaterial({visible:false}));headHit.position.y=1.7;group.add(headHit);
  const bot={id:`bot-${index}`,name:`BOT-${String(index+1).padStart(2,'0')}`,group,health:100,alive:true,respawnAt:0,nextShot:performance.now()+1300+Math.random()*1600,nextMove:0,target:new THREE.Vector3((Math.random()-.5)*65,0,(Math.random()-.5)*65),speed:2+Math.random()*.55,bodyMat,hitMeshes:[bodyHit,headHit]};
  bodyHit.userData.target=bot;headHit.userData.target=bot;botTargets.push(bodyHit,headHit);bots.push(bot);return bot;
}
[[-34,-35],[34,-34],[-37,35],[36,34],[0,-38],[0,36]].forEach((p,i)=>createBot(i,p[0],p[1]));

const remotePlayers=new Map();const remoteTargets=[];
function createRemote(p){
  if(!p||!p.id||p.id===playerId)return;
  if(remotePlayers.has(p.id)){updateRemote(remotePlayers.get(p.id),p);return;}
  const group=new THREE.Group();const bodyMat=new THREE.MeshStandardMaterial({color:0x4d89a8,roughness:.72});const dark=new THREE.MeshStandardMaterial({color:0x202a34,roughness:.7});
  const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.28,.55,4,7),bodyMat);torso.position.y=1.0;group.add(torso);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.22,10,8),new THREE.MeshStandardMaterial({color:0xb5c3cb,roughness:.82}));head.position.y=1.65;group.add(head);
  const pack=new THREE.Mesh(new THREE.BoxGeometry(.36,.45,.16),dark);pack.position.set(0,1.08,.25);group.add(pack);
  for(const s of [-1,1]){const leg=new THREE.Mesh(new THREE.BoxGeometry(.2,.63,.22),dark);leg.position.set(s*.16,.36,0);group.add(leg);const arm=new THREE.Mesh(new THREE.BoxGeometry(.16,.57,.18),bodyMat);arm.position.set(s*.37,1.05,0);group.add(arm);}
  const tag=makeNameSprite(p.name,'#6ebce3');group.add(tag);scene.add(group);
  const hitBody=new THREE.Mesh(new THREE.CapsuleGeometry(.34,.6,3,6),new THREE.MeshBasicMaterial({visible:false}));hitBody.position.y=1;group.add(hitBody);
  const hitHead=new THREE.Mesh(new THREE.SphereGeometry(.25,8,6),new THREE.MeshBasicMaterial({visible:false}));hitHead.position.y=1.65;group.add(hitHead);
  const remote={id:p.id,name:p.name,group,target:new THREE.Vector3(p.x,0,p.z),yaw:p.yaw||0,health:p.health??100,kills:p.kills||0,deaths:p.deaths||0,hitMeshes:[hitBody,hitHead]};
  hitBody.userData.target=remote;hitHead.userData.target=remote;remoteTargets.push(hitBody,hitHead);remotePlayers.set(p.id,remote);updateRemote(remote,p);
}
function updateRemote(remote,p){remote.name=p.name||remote.name;remote.target.set(p.x||0,0,p.z||0);remote.yaw=p.yaw||0;remote.health=p.health??remote.health;remote.kills=p.kills??remote.kills;remote.deaths=p.deaths??remote.deaths;}
function removeRemote(id){const r=remotePlayers.get(id);if(!r)return;scene.remove(r.group);r.hitMeshes.forEach(m=>{const i=remoteTargets.indexOf(m);if(i>=0)remoteTargets.splice(i,1);});remotePlayers.delete(id);}

const raycaster=new THREE.Raycaster();raycaster.far=170;
const tracerMaterials=[];
function makeTracer(start,end,color=0xffd17a,life=.095){const geo=new THREE.BufferGeometry().setFromPoints([start.clone(),end.clone()]);const mat=new THREE.LineBasicMaterial({color,transparent:true,opacity:.9});const line=new THREE.Line(geo,mat);scene.add(line);tracerMaterials.push({line,mat,expires:performance.now()+life*1000});}
function impactEffect(point,color=0xffc96a){const g=new THREE.SphereGeometry(.07,6,5);const m=new THREE.MeshBasicMaterial({color,transparent:true});const s=new THREE.Mesh(g,m);s.position.copy(point);scene.add(s);setTimeout(()=>{scene.remove(s);g.dispose();m.dispose();},130);}

function getPlayerPos(){return camera.position;}
function moveBlocked(x,z,r=.42){
  if(x<-47+r||x>47-r||z<-47+r||z>47-r)return true;
  for(const c of colliders){if(Math.abs(x-c.x)<c.hx+r&&Math.abs(z-c.z)<c.hz+r)return true;}
  return false;
}
function updateHUD(){
  $('healthText').textContent=Math.max(0,Math.ceil(playerHealth));$('armorText').textContent=Math.max(0,Math.ceil(playerArmor));
  $('healthBar').style.width=`${Math.max(0,playerHealth)}%`;$('armorBar').style.width=`${Math.max(0,playerArmor*2)}%`;
  const w=weapons[currentWeapon];$('weaponName').textContent=w.name;$('ammoNow').textContent=w.ammo;$('ammoReserve').textContent=w.reserve;
  $('reloadTag').classList.toggle('show',w.busy);$('kdText').textContent=`${localKills} / ${localDeaths}`;
  [...$('slots').children].forEach((el,i)=>el.classList.toggle('active',i===currentWeapon));
}
function buildSlots(){const root=$('slots');root.innerHTML='';weapons.forEach((w,i)=>{const el=document.createElement('div');el.className='slot';el.innerHTML=`<b>${w.slot}</b><span>${w.short}</span>`;root.appendChild(el);});}
buildSlots();updateHUD();
function setWeapon(index){if(index<0||index>=weapons.length||weapons[index].busy)return;currentWeapon=index;buildViewWeapon(weapons[index]);aiming=false;updateHUD();}
function showToast(text){const el=$('toast');el.textContent=text;el.classList.add('show');clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>el.classList.remove('show'),1700);}
function addFeed(text){const line=document.createElement('div');line.className='feed-line';line.textContent=text;$('feed').prepend(line);while($('feed').children.length>5)$('feed').lastChild.remove();setTimeout(()=>line.remove(),5200);}
function showHitmarker(){const h=$('hitmarker');h.classList.remove('show');void h.offsetWidth;h.classList.add('show');}

let audioCtx=null;
function sound(freq=130,kind='triangle',duration=.06,vol=.15){if(settings.volume<=0)return;try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type=kind;osc.frequency.setValueAtTime(freq,audioCtx.currentTime);osc.frequency.exponentialRampToValueAtTime(Math.max(35,freq*.42),audioCtx.currentTime+duration);gain.gain.setValueAtTime((settings.volume/100)*vol,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);osc.connect(gain);gain.connect(audioCtx.destination);osc.start();osc.stop(audioCtx.currentTime+duration);}catch{}}
function reload(){const w=weapons[currentWeapon];if(w.busy||w.ammo===w.mag||w.reserve<=0)return;w.busy=true;aiming=false;updateHUD();sound(270,'sine',.12,.09);reloadTimer=setTimeout(()=>{const n=Math.min(w.mag-w.ammo,w.reserve);w.ammo+=n;w.reserve-=n;w.busy=false;updateHUD();sound(460,'triangle',.08,.08);},w.reload);}
function getAimDirection(spread=0){const dir=new THREE.Vector3(0,0,-1);dir.applyEuler(camera.rotation);dir.x+=(Math.random()-.5)*spread;dir.y+=(Math.random()-.5)*spread;dir.z+=(Math.random()-.5)*spread;return dir.normalize();}
function fireOne(){
  const w=weapons[currentWeapon],now=performance.now();
  if(!gameStarted||!isLocked||w.busy||now-lastShot<w.rate)return;
  if(w.ammo<=0){sound(100,'square',.035,.06);if(w.reserve>0)reload();else showToast('Sem munição');return;}
  lastShot=now;w.ammo--;updateHUD();sound(w.slot==='4'?90:w.slot==='5'?72:125,'sawtooth',w.slot==='5'?.13:.075,.18);
  muzzleLight.intensity=2.7;muzzleFlashUntil=now+55;
  if(socket&&socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify({type:'fire',weapon:w.name}));
  const pellets=w.pellets||1;let hitAnything=false;
  for(let i=0;i<pellets;i++){
    const dir=getAimDirection(w.spread*(aiming?.48:1));const start=camera.position.clone().add(dir.clone().multiplyScalar(.7));
    raycaster.set(camera.position,dir);raycaster.far=w.range;
    const targets=[...botTargets,...remoteTargets,...worldMeshes];const hits=raycaster.intersectObjects(targets,false);
    let end=camera.position.clone().add(dir.clone().multiplyScalar(w.range));
    if(hits.length){const hit=hits[0];end.copy(hit.point);const target=hit.object.userData.target;
      if(target&&target.alive!==false&&target.health>0){
        hitAnything=true;const damage=w.damage*(hit.object.geometry.type==='SphereGeometry'?1.25:1);
        if(String(target.id).startsWith('bot-')){
          target.health-=damage;impactEffect(hit.point,0xffd18b);
          if(target.health<=0){target.alive=false;target.group.visible=false;target.respawnAt=performance.now()+3000;localKills++;updateHUD();addFeed(`VOCÊ  ✦  ${target.name}`);}
        }else if(target.id&&socket&&socket.readyState===WebSocket.OPEN){socket.send(JSON.stringify({type:'hit',target:target.id,damage:Math.min(60,damage)}));impactEffect(hit.point,0x83d5ec);}
      }else impactEffect(hit.point,0xc8d0d2);
    }
    makeTracer(start,end,w.slot==='4'?0x94d7ef:0xffd17a,.075);
  }
  if(hitAnything)showHitmarker();
  if(w.ammo===0&&w.reserve>0)setTimeout(()=>{if(weapons[currentWeapon]===w)showToast('Carregador vazio — pressione R');},250);
}
function shoot(){const w=weapons[currentWeapon];if(w.auto){if(firing)fireOne();}else fireOne();}

// Movement / player status.
function damagePlayer(amount,source='BOT'){
  if(respawning)return;let dmg=amount;
  const absorbed=Math.min(playerArmor,dmg*.7);playerArmor-=absorbed;dmg-=absorbed;playerHealth=Math.max(0,playerHealth-dmg);updateHUD();
  if(playerHealth<=0){localDeaths++;updateHUD();addFeed(`${source}  ✦  VOCÊ`);respawning=true;setTimeout(()=>{camera.position.set((Math.random()-.5)*20,1.65,38);playerHealth=100;playerArmor=50;respawning=false;updateHUD();showToast('Você voltou para a arena');},2600);}
}
function updateMovement(dt){
  const speed=(keys.Shift?8.3:5.6);const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
  let move=new THREE.Vector3();if(keys.KeyW||keys.w)move.add(forward);if(keys.KeyS||keys.s)move.sub(forward);if(keys.KeyD||keys.d)move.add(right);if(keys.KeyA||keys.a)move.sub(right);
  if(move.lengthSq()>0){move.normalize().multiplyScalar(speed*dt);const p=camera.position;let nx=p.x+move.x,nz=p.z+move.z;if(!moveBlocked(nx,p.z))p.x=nx;if(!moveBlocked(p.x,nz))p.z=nz;}
  if(keys.Space&&onGround){verticalVelocity=5.7;onGround=false;keys.Space=false;}
  verticalVelocity-=15*dt;camera.position.y+=verticalVelocity*dt;if(camera.position.y<1.65){camera.position.y=1.65;verticalVelocity=0;onGround=true;}
  camera.position.x=THREE.MathUtils.clamp(camera.position.x,-47,47);camera.position.z=THREE.MathUtils.clamp(camera.position.z,-47,47);
  camera.rotation.set(pitch,yaw,0,'YXZ');
  const baseFov=aiming?weapons[currentWeapon].aimFov:settings.fov;camera.fov=THREE.MathUtils.lerp(camera.fov,baseFov,Math.min(1,dt*12));camera.updateProjectionMatrix();
  if(viewWeapon){viewWeapon.position.x=THREE.MathUtils.lerp(viewWeapon.position.x,aiming?.12:.34,dt*10);viewWeapon.position.y=THREE.MathUtils.lerp(viewWeapon.position.y,aiming?-.24:-.31,dt*10);viewWeapon.rotation.z=THREE.MathUtils.lerp(viewWeapon.rotation.z,move.lengthSq()>.001?Math.sin(performance.now()*.012)*.018:0,dt*8);}
  if(firing)shoot();
  if(socket&&socket.readyState===WebSocket.OPEN&&gameStarted&&Math.random()<dt*12){socket.send(JSON.stringify({type:'state',x:camera.position.x,y:camera.position.y,z:camera.position.z,yaw,pitch}));}
}

function hasLineOfSight(from,to){const delta=to.clone().sub(from);const dist=delta.length();raycaster.set(from,delta.normalize());raycaster.far=dist;const hits=raycaster.intersectObjects(worldMeshes,false);return hits.length===0;}
function updateBots(dt,now){
  for(const bot of bots){
    if(!bot.alive){if(now>bot.respawnAt){bot.alive=true;bot.health=100;bot.group.visible=true;const spots=[[-37,-36],[37,-35],[-38,36],[37,36],[0,-38],[0,37]];const p=spots[Number(bot.id.split('-')[1])-1];bot.group.position.set(p[0],0,p[1]);bot.nextShot=now+1200;}continue;}
    const pos=bot.group.position;const toPlayer=new THREE.Vector3(camera.position.x-pos.x,0,camera.position.z-pos.z);const dist=toPlayer.length();
    let dir=new THREE.Vector3();
    if(dist>13){dir.copy(toPlayer.normalize());}
    else if(dist>5){dir.set(-toPlayer.z,0,toPlayer.x).normalize().multiplyScalar(Math.sin(now*.001+Number(bot.id.split('-')[1]))>.0?1:-1);}
    else {dir.copy(toPlayer.normalize()).multiplyScalar(-.6);}
    if(dist>43){if(pos.distanceTo(bot.target)<2)bot.target.set((Math.random()-.5)*70,0,(Math.random()-.5)*70);dir.copy(bot.target.clone().sub(pos).normalize());}
    const step=dir.multiplyScalar(bot.speed*dt);const nx=pos.x+step.x,nz=pos.z+step.z;
    if(!moveBlocked(nx,nz,.5)){pos.x=nx;pos.z=nz;}else{bot.target.set((Math.random()-.5)*65,0,(Math.random()-.5)*65);}
    if(dist>.4)bot.group.rotation.y=Math.atan2(-toPlayer.x,-toPlayer.z);
    if(dist<32&&now>bot.nextShot){bot.nextShot=now+1200+Math.random()*1200;const from=pos.clone().add(new THREE.Vector3(0,1.3,0));const target=camera.position.clone();const aim=target.clone().sub(from).normalize();const shotEnd=from.clone().add(aim.multiplyScalar(Math.min(dist,27)));makeTracer(from,shotEnd,0xe18b67,.09);if(hasLineOfSight(from,target)&&Math.random()<.34)damagePlayer(5+Math.random()*4,bot.name);}
  }
}
function updateRemotes(dt){for(const r of remotePlayers.values()){r.group.position.lerp(r.target,Math.min(1,dt*12));r.group.rotation.y=r.yaw;}}
function updateTracers(){const now=performance.now();for(let i=tracerMaterials.length-1;i>=0;i--){const t=tracerMaterials[i];const left=(t.expires-now)/100;if(left<=0){scene.remove(t.line);t.line.geometry.dispose();t.mat.dispose();tracerMaterials.splice(i,1);}else t.mat.opacity=Math.min(.9,left);}}

// Multiplayer: the WebSocket server relays player movement and validates basic hits.
function connectMultiplayer(){
  if(location.protocol==='file:'){setConnection(false,'OFFLINE');return;}
  const protocol=location.protocol==='https:'?'wss:':'ws:';
  try{socket=new WebSocket(`${protocol}//${location.host}`);}catch{setConnection(false,'OFFLINE');return;}
  socket.addEventListener('open',()=>{socket.send(JSON.stringify({type:'join',name:playerName}));setConnection(true,'CONECTANDO');});
  socket.addEventListener('message',(event)=>{
    let msg;try{msg=JSON.parse(event.data);}catch{return;}
    if(msg.type==='welcome'){
      playerId=msg.id;online=true;setConnection(true,'ONLINE');(msg.players||[]).forEach(createRemote);showToast('Conectado ao multiplayer');
    }else if(msg.type==='player_joined'){createRemote(msg.player);addFeed(`${msg.player.name} entrou na arena`);}
    else if(msg.type==='player_state'){const r=remotePlayers.get(msg.player.id);if(r)updateRemote(r,msg.player);else createRemote(msg.player);}
    else if(msg.type==='player_left'){removeRemote(msg.id);addFeed(`${msg.name||'Jogador'} saiu da arena`);}
    else if(msg.type==='player_fire'){
      const dir=new THREE.Vector3(-Math.sin(msg.yaw||0),Math.tan(msg.pitch||0),-Math.cos(msg.yaw||0)).normalize();const start=new THREE.Vector3(msg.x,msg.y,msg.z);makeTracer(start,start.add(dir.multiplyScalar(34)),0x82d5f3,.07);
    }else if(msg.type==='player_hit'){const target=remotePlayers.get(msg.targetId);if(target)target.health=msg.health;if(msg.targetId===playerId)showHitmarker();}
    else if(msg.type==='player_killed'){const deadRemote=remotePlayers.get(msg.targetId);if(deadRemote)deadRemote.group.visible=false;if(msg.killerId===playerId){localKills++;updateHUD();addFeed(`VOCÊ  ✦  ${msg.targetName}`);}else if(msg.targetId===playerId){localDeaths++;updateHUD();addFeed(`${msg.killerName}  ✦  VOCÊ`);}}
    else if(msg.type==='player_respawn'){createRemote(msg.player);const revived=remotePlayers.get(msg.player.id);if(revived)revived.group.visible=true;}
    else if(msg.type==='health'){playerHealth=msg.health;updateHUD();if(playerHealth<=0&&!respawning){respawning=true;setTimeout(()=>{camera.position.set((Math.random()-.5)*24,1.65,38);playerHealth=100;playerArmor=50;respawning=false;updateHUD();},2600);}}
    else if(msg.type==='you_respawned'){camera.position.set(msg.player.x,msg.player.y,msg.player.z);playerHealth=100;playerArmor=50;respawning=false;updateHUD();}
    else if(msg.type==='stats'){localKills=msg.kills||localKills;localDeaths=msg.deaths||localDeaths;updateHUD();}
    else if(msg.type==='chat'){addChat(msg.name,msg.text);}
  });
  socket.addEventListener('close',()=>{online=false;setConnection(false,'OFFLINE');for(const id of [...remotePlayers.keys()])removeRemote(id);});
  socket.addEventListener('error',()=>{setConnection(false,'SEM SERVIDOR');});
}
function setConnection(ok,text){$('connDot').classList.toggle('online',ok);$('connText').textContent=text;$('serverStatusMenu').textContent=ok?'● Multiplayer conectado':'● Bots / servidor não encontrado';}
function addChat(name,text){const line=document.createElement('div');line.className='chatline';const strong=document.createElement('strong');strong.textContent=`${name}: `;line.append(strong,document.createTextNode(text));$('chatbox').appendChild(line);while($('chatbox').children.length>5)$('chatbox').firstChild.remove();}
function refreshScoreboard(){const rows=[{name:playerName,kills:localKills,deaths:localDeaths,online:true,me:true},...Array.from(remotePlayers.values()).map(r=>({name:r.name,kills:r.kills,deaths:r.deaths,online:true})),...bots.map(b=>({name:b.name,kills:0,deaths:0,online:false}))];$('scoreRows').innerHTML='';rows.sort((a,b)=>b.kills-a.kills).forEach(r=>{const tr=document.createElement('tr');if(r.me)tr.className='me';const cells=[r.name,r.kills,r.deaths,r.online?'ATIVO':'BOT'];cells.forEach((c,i)=>{const td=document.createElement('td');td.textContent=c;tr.appendChild(td);});$('scoreRows').appendChild(tr);});}

function startGame(){
  playerName=$('playerName').value.trim().slice(0,16)||'Player';$('mainMenu').style.display='none';$('hud').style.display='block';gameStarted=true;connectMultiplayer();renderer.domElement.requestPointerLock?.();showToast('Elimine os bots e domine a arena');
}
$('playBtn').addEventListener('click',startGame);
$('settingsBtn').addEventListener('click',()=>$('settingsModal').classList.add('open'));
$('closeSettings').addEventListener('click',()=>$('settingsModal').classList.remove('open'));
$('saveSettings').addEventListener('click',()=>{$('settingsModal').classList.remove('open');applySettings();showToast('Configurações aplicadas');});
function bindRange(id,out,format){$(id).addEventListener('input',()=>$(out).textContent=format($(id).value));}
bindRange('sensitivity','sensOut',v=>`${Number(v).toFixed(1)}x`);bindRange('fov','fovOut',v=>`${v}°`);bindRange('saturation','satOut',v=>`${v}%`);bindRange('volume','volumeOut',v=>`${v}%`);
function applySettings(){settings.sensitivity=Number($('sensitivity').value);settings.fov=Number($('fov').value);settings.saturation=Number($('saturation').value);settings.volume=Number($('volume').value);settings.quality=$('quality').value;renderer.domElement.style.filter=`saturate(${settings.saturation/100})`;renderer.setPixelRatio(Math.min(devicePixelRatio,settings.quality==='high'?2:settings.quality==='medium'?1.5:1));renderer.shadowMap.enabled=settings.quality==='high';camera.fov=settings.fov;camera.updateProjectionMatrix();}

// Keyboard and mouse controls.
document.addEventListener('pointerlockchange',()=>{isLocked=document.pointerLockElement===renderer.domElement;$('pauseHint').style.display=gameStarted&&!isLocked&&!$('settingsModal').classList.contains('open')?'block':'none';if(!isLocked){firing=false;aiming=false;}});
document.addEventListener('mousemove',(e)=>{if(!isLocked||chatOpen)return;yaw-=e.movementX*.0022*settings.sensitivity;pitch-=e.movementY*.0022*settings.sensitivity;pitch=THREE.MathUtils.clamp(pitch,-1.48,1.48);});
document.addEventListener('mousedown',(e)=>{if(!gameStarted||!isLocked||chatOpen)return;if(e.button===0){firing=true;if(!weapons[currentWeapon].auto)fireOne();}if(e.button===2){aiming=true;}});
document.addEventListener('mouseup',(e)=>{if(e.button===0)firing=false;if(e.button===2)aiming=false;});
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('keydown',(e)=>{
  if(['Space','Tab'].includes(e.code))e.preventDefault();
  if(chatOpen){if(e.key==='Enter'){const text=$('chatinput').value.trim();if(text&&socket&&socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify({type:'chat',text}));$('chatinput').value='';$('chatinput').style.display='none';chatOpen=false;if(isLocked)renderer.domElement.requestPointerLock?.();}if(e.key==='Escape'){$('chatinput').style.display='none';chatOpen=false;}return;}
  keys[e.code]=true;keys[e.key.toLowerCase()]=true;
  if(e.code==='KeyR')reload();
  if(e.code==='Digit1')setWeapon(0);if(e.code==='Digit2')setWeapon(1);if(e.code==='Digit3')setWeapon(2);if(e.code==='Digit4')setWeapon(3);if(e.code==='Digit5')setWeapon(4);if(e.code==='Digit6')setWeapon(5);if(e.code==='Digit7')setWeapon(6);if(e.code==='Digit9')setWeapon(7);
  if(e.code==='Tab'&&gameStarted){scoreboardOpen=true;refreshScoreboard();$('scoreboard').classList.add('show');}
  if(e.code==='KeyT'&&gameStarted){chatOpen=true;$('chatinput').style.display='block';$('chatinput').focus();document.exitPointerLock?.();}
});
document.addEventListener('keyup',(e)=>{keys[e.code]=false;keys[e.key.toLowerCase()]=false;if(e.code==='Tab'){scoreboardOpen=false;$('scoreboard').classList.remove('show');}});
window.addEventListener('blur',()=>{firing=false;aiming=false;});

// Main render loop.
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);const now=performance.now();
  if(gameStarted){if(isLocked)updateMovement(dt);else{camera.rotation.set(pitch,yaw,0,'YXZ');}updateBots(dt,now);updateRemotes(dt);updateTracers();if(muzzleLight&&now>muzzleFlashUntil)muzzleLight.intensity=0;}
  renderer.render(scene,camera);
}
animate();
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});

// Keep the game playable in a solo file preview; the server is only required for online players.
setConnection(false,'OFFLINE');
